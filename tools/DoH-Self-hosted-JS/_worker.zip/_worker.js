// 定义路径与上游服务器的映射关系（不带 /dns-query）
const routes = {
  '/cloudflare': 'https://one.one.one.one',
  '/google': 'https://dns.google',
  '/ali': 'https://dns.alidns.com',
  '/tencent': 'https://dns.pub',
};

function getHost(req) {
  const u = new URL(req.url);
  return u.host;
}

function buildPage(req) {
  const host = getHost(req);
  
  const services = [
    { name: 'Cloudflare', path: '/cloudflare', upstream: 'one.one.one.one/dns-query' },
    { name: 'Google', path: '/google', upstream: 'dns.google/dns-query' },
    { name: '阿里 DNS', path: '/ali', upstream: 'dns.alidns.com/dns-query' },
    { name: '腾讯 DNS', path: '/tencent', upstream: 'dns.pub/dns-query' }
  ];
  
  let cardsHtml = '';
  for (const s of services) {
    const selfUrl = 'https://' + host + s.path + '/dns-query';
    cardsHtml += `
      <div class="group-card">
        <div class="item-header">
          <span class="item-title">` + s.name + `</span>
        </div>
        <div class="item-desc">上游：` + s.upstream + `</div>
        <div class="action-area">
          <div class="url-box"><span class="url-text">` + selfUrl + `</span></div>
          <button class="copy-btn" data-url="` + selfUrl + `">复制链接</button>
        </div>
        <div class="ping-row">
          <span class="ping-label">延迟</span>
          <span class="ping-value" id="ping-` + s.path.replace('/', '') + `">检测中...</span>
        </div>
      </div>
    `;
  }
  
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>自建 DoH 服务</title>
    <style>
        :root { --bg-color: #0f172a; --card-bg: rgba(30, 41, 59, 0.7); --accent-blue: #3b82f6; --text-main: #f1f5f9; --text-muted: #94a3b8; --border-color: rgba(255, 255, 255, 0.08); --code-bg: rgba(15, 23, 42, 0.6); }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background-color: var(--bg-color); background-image: radial-gradient(circle at 50% 0%, rgba(59, 130, 246, 0.18) 0%, transparent 600px); background-repeat: no-repeat; color: var(--text-main); line-height: 1.6; padding: 50px 20px; }
        .container { max-width: 850px; margin: 0 auto; }
        header { text-align: center; margin-bottom: 50px; }
        h1 { font-size: 2.2rem; margin-bottom: 20px; font-weight: 800; letter-spacing: -0.02em; background: linear-gradient(to right, #ffffff, var(--accent-blue)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
        footer { text-align: center; margin-top: 50px; padding-top: 30px; border-top: 1px solid var(--border-color); }
        .tips { display: block; font-size: 0.9rem; color: var(--text-muted); margin-bottom: 15px; }
        .ad-button { display: inline-block; background: linear-gradient(135deg, rgba(59, 130, 246, 0.8), rgba(37, 99, 235, 0.8)); color: #fff; padding: 10px 28px; border-radius: 50px; text-decoration: none; font-size: 0.95rem; font-weight: 700; transition: 0.3s; box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); }
        .ad-button:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3); }
        section { margin-bottom: 50px; }
        h2 { font-size: 1.7rem; margin-bottom: 25px; color: #fff; display: flex; align-items: center; }
        h2::before { content: ""; width: 5px; height: 1.4rem; background: var(--accent-blue); margin-right: 15px; border-radius: 10px; box-shadow: 0 0 15px var(--accent-blue), 0 0 5px rgba(59, 130, 246, 0.5); }
        .group-card { background-color: var(--card-bg); border: 1px solid var(--border-color); border-radius: 14px; padding: 22px; margin-bottom: 20px; box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2); }
        .item-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; flex-wrap: wrap; }
        .item-title { font-weight: 700; color: #fff; font-size: 1.2rem; line-height: 1; }
        .item-desc { display: block; font-size: 0.75rem; color: #94a3b8; line-height: 1.4; margin-bottom: 12px; font-weight: normal; }
        .action-area { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; }
        .url-box { flex: 1; background-color: var(--code-bg); padding: 0 16px; height: 42px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.05); display: flex; align-items: center; }
        .url-text { font-family: ui-monospace, SFMono-Regular, Monaco, Consolas, monospace; font-size: 0.85rem; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; user-select: all; width: 100%; }
        .copy-btn { background: rgba(59, 130, 246, 0.15); color: var(--accent-blue); border: 1px solid rgba(59, 130, 246, 0.4); height: 42px; padding: 0 20px; border-radius: 8px; cursor: pointer; font-size: 0.85rem; font-weight: 700; transition: all 0.3s; white-space: nowrap; display: flex; align-items: center; justify-content: center; }
        .copy-btn:hover { background: var(--accent-blue); color: #fff; box-shadow: 0 0 15px rgba(59, 130, 246, 0.3); }
        .copy-btn.success { background: #10b981; border-color: #10b981; color: #fff; }
        .ping-row { display: flex; align-items: center; gap: 10px; margin-top: 12px; padding-top: 10px; border-top: 1px solid var(--border-color); }
        .ping-label { font-size: 0.7rem; color: var(--text-muted); }
        .ping-value { font-family: monospace; font-size: 0.85rem; font-weight: 600; }
        .ping-value.low { color: #10b981; }
        .ping-value.medium { color: #f59e0b; }
        .ping-value.high { color: #ef4444; }
        @media (max-width: 600px) { 
            .action-area { flex-direction: column; align-items: stretch; gap: 10px; } 
            .url-box { height: 42px !important; min-height: 42px !important; display: flex !important; align-items: center !important; padding: 0 15px !important; } 
            .copy-btn { height: 42px !important; padding: 0 !important; width: 100% !important; } 
            .url-text { font-size: 0.7rem !important; } 
        }
        @keyframes glow-breath { 0%, 100% { box-shadow: 0 0 5px #3b82f688; filter: brightness(1); } 50% { box-shadow: 0 0 25px #3b82f6, 0 0 10px #3b82f6; filter: brightness(1.5); } }
        h2.breath::before { animation: glow-breath 4s ease-in-out infinite !important; }
    </style>
</head>
<body>
<div class="container">
    <header>
        <h1>自建 DoH <span style="display: inline-block;">服务</span></h1>
    </header>
    <section>
        ` + cardsHtml + `
    </section>
    <footer>
        <span class="tips">安全加密 · 支持 ECH</span>
        <a href="https://www.youtube.com/@zhenxiangdinglv" target="_blank" class="ad-button">YouTube 真香定律</a>
    </footer>
</div>
<div id="toast" style="position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#1e293b;color:#fff;padding:8px 20px;border-radius:30px;font-size:0.8rem;z-index:1000;display:none;"></div>
<script>
function showMsg(txt){
    var t=document.getElementById('toast');
    t.textContent=txt;
    t.style.display='block';
    setTimeout(function(){t.style.display='none';},2000);
}
function copyUrl(str,btn){
    var old=btn.textContent;
    if(navigator.clipboard){
        navigator.clipboard.writeText(str).then(function(){
            showMsg('已复制');
            btn.textContent='已复制';
            btn.classList.add('success');
            setTimeout(function(){btn.textContent=old;btn.classList.remove('success');},1800);
        }).catch(function(){fallbackCopy(str,btn);});
    }else{fallbackCopy(str,btn);}
}
function fallbackCopy(str,btn){
    var old=btn.textContent;
    var ta=document.createElement('textarea');
    ta.value=str;
    ta.style.position='fixed';
    ta.style.opacity='0';
    document.body.appendChild(ta);
    ta.select();
    try{
        document.execCommand('copy');
        showMsg('已复制');
        btn.textContent='已复制';
        btn.classList.add('success');
        setTimeout(function(){btn.textContent=old;btn.classList.remove('success');},1800);
    }catch(e){showMsg('复制失败');}
    document.body.removeChild(ta);
}
// 修复后：直接测试客户端到自建 DoH 的延迟
function testLatency(pingEl) {
    var start = Date.now();
    fetch('/', { method: 'HEAD' }).then(function() {
        var latency = Date.now() - start;
        pingEl.textContent = latency + 'ms';
        pingEl.className = 'ping-value';
        if (latency < 50) pingEl.classList.add('low');
        else if (latency < 150) pingEl.classList.add('medium');
        else pingEl.classList.add('high');
    }).catch(function() {
        pingEl.textContent = '超时';
        pingEl.className = 'ping-value high';
    });
}
function testAll(){
    var pings = document.querySelectorAll('.ping-value');
    for(var i = 0; i < pings.length; i++){
        testLatency(pings[i]);
    }
}
var btns=document.querySelectorAll('.copy-btn');
for(var i=0;i<btns.length;i++){
    btns[i].addEventListener('click',function(e){
        var url=this.getAttribute('data-url');
        if(url) copyUrl(url,this);
    });
}
testAll();
setInterval(testAll, 3000);
</script>
</body>
</html>`;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    
    if (url.pathname === '/' || url.pathname === '') {
      return new Response(buildPage(request), {
        headers: { 'Content-Type': 'text/html; charset=utf-8' }
      });
    }
    
    for (const [path, upstream] of Object.entries(routes)) {
      if (url.pathname.startsWith(path)) {
        // 客户端请求 /cloudflare/dns-query
        // path = '/cloudflare', 剩余 = '/dns-query'
        // 最终拼接: https://one.one.one.one + /dns-query ✅
        const newUrl = upstream + url.pathname.slice(path.length);
        const newRequest = new Request(newUrl, request);
        newRequest.headers.set('Host', new URL(upstream).hostname);
        return fetch(newRequest);
      }
    }
    
    return new Response('Not Found', { status: 404 });
  }    
};