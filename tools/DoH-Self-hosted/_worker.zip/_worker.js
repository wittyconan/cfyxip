const routes = {
  '/cloudflare': 'https://one.one.one.one',
  '/google': 'https://dns.google',
  '/ali': 'https://dns.alidns.com',
  '/tencent': 'https://dns.pub',
  '/quad9': 'https://dns.quad9.net',
  '/sb': 'https://doh.dns.sb',
  '/nextdns': 'https://dns.nextdns.io',
  '/adguard': 'https://dns.adguard.com',
  '/mullvad': 'https://dns.mullvad.net',
  '/opendns': 'https://doh.opendns.com',
};

function getHost(req) {
  const u = new URL(req.url);
  return u.host;
}

function buildPage(req) {
  const host = getHost(req);
  const services = [
    { name: 'Cloudflare(推荐)', path: '/cloudflare', upstream: 'https://one.one.one.one/dns-query', desc: '全球响应快，支持 ECH 和 DoH3，隐私保护极佳' },
    { name: 'Google DNS', path: '/google', upstream: 'https://dns.google/dns-query', desc: '全球部署最广的工业级标准 DNS，解析结果精准可靠' },
    { name: '阿里 DNS', path: '/ali', upstream: 'https://dns.alidns.com/dns-query', desc: '国内解析首选，支持 ECS 提高 CDN 命中率' },
    { name: '腾讯 DNS', path: '/tencent', upstream: 'https://dns.pub/dns-query', desc: '国内移动端优化极佳，解析稳定，支持多种加密协议' },
    { name: 'Quad9', path: '/quad9', upstream: 'https://dns.quad9.net/dns-query', desc: '主打安全拦截，通过情报库实时拦截恶意域名，瑞士背景' },
    { name: 'DNS.SB', path: '/sb', upstream: 'https://doh.dns.sb/dns-query', desc: '无日志、无审查，极速解析且支持最新的隐私加密标准' },
    { name: 'NextDNS', path: '/nextdns', upstream: 'https://dns.nextdns.io/dns-query', desc: '新一代防火墙 DNS，支持深度自定义过滤规则与分析报告' },
    { name: 'AdGuard DNS', path: '/adguard', upstream: 'https://dns.adguard.com/dns-query', desc: '强大的内置广告拦截，支持 DNS-over-QUIC 协议' },
    { name: 'Mullvad DNS', path: '/mullvad', upstream: 'https://dns.mullvad.net/dns-query', desc: '极致隐私，无日志瑞典服务，由知名 VPN 服务商提供' },
    { name: 'OpenDNS', path: '/opendns', upstream: 'https://doh.opendns.com/dns-query', desc: '思科旗下老牌服务，稳定可靠，提供出色的安全防护' }
  ];
  
  let cardsHtml = '';
  for (const s of services) {
    const selfUrl = 'https://' + host + s.path + '/dns-query';
    const id = s.path.replace('/', '');
    cardsHtml += `
      <div class="group-card">
        <div class="item-header">
          <span class="item-title">${s.name}</span>
        </div>
        
        <div class="item-row">
            <span class="value">${s.desc}</span>
        </div>

        <div class="input-section">
            <div class="label-row">
                上游 DoH 地址 - <span id="up-ping-${id}" class="ping-value">延迟检测中...</span>
            </div>
            <div class="url-box no-btn">
                <span class="url-text">${s.upstream}</span>
            </div>
        </div>

        <div class="input-section">
            <div class="label-row">
                反代 DoH 地址 - <span id="proxy-ping-${id}" class="ping-value">延迟检测中...</span>
            </div>
            <div class="action-area">
              <div class="url-box"><span class="url-text">${selfUrl}</span></div>
              <button class="copy-btn" data-url="${selfUrl}">复制链接</button>
            </div>
        </div>
      </div>
    `;
  }
  
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>自建 DoH 服务</title>
	<style>
		:root { 
			--bg-color: #0f172a; 
			--card-bg: rgba(30, 41, 59, 0.7); 
			--accent-blue: #3b82f6; 
			--text-main: #94a3b8; 
			--text-muted: #94a3b8; 
			--border-color: rgba(255, 255, 255, 0.08); 
			--code-bg: rgba(15, 23, 42, 0.6); 
		}
		
		* { box-sizing: border-box; margin: 0; padding: 0; }
		
		body { 
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; 
			background-color: var(--bg-color); 
			background-image: radial-gradient(circle at 50% 0%, rgba(59, 130, 246, 0.18) 0%, transparent 600px); 
			background-repeat: no-repeat; 
			color: var(--text-main); 
			line-height: 1.6; 
			padding: 50px 20px; 
		}

		.container { max-width: 850px; margin: 0 auto; }
		
		header { text-align: center; margin-bottom: 50px; }
		
		h1 { 
			font-size: 2.2rem; 
			margin-bottom: 8px; 
			font-weight: 800; 
			letter-spacing: -0.02em; 
			background: linear-gradient(to right, #ffffff, var(--accent-blue)); 
			-webkit-background-clip: text; 
			-webkit-text-fill-color: transparent; 
		}

		.sub-title { font-size: 0.95rem; color: var(--text-muted); font-weight: 500; letter-spacing: 0.05em; }

		.group-card { 
			background-color: var(--card-bg); 
			border: 1px solid var(--border-color); 
			border-radius: 14px; 
			padding: 22px; 
			margin-bottom: 25px; 
			box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2); 
		}

		.item-header { margin-bottom: 12px; }

		.item-title { font-weight: 700; color: #fff; font-size: 1.25rem; }

		/* 优化特点行：确保字体大小和颜色与地址栏标签完全一致 */
		.item-row { 
			display: flex; 
			gap: 8px; 
			font-size: 0.85rem; 
			margin-bottom: 15px; 
			align-items: flex-start; 
		}

		.label { 
			font-weight: 600; 
			color: var(--text-muted); 
			white-space: nowrap; 
		}

		.value { 
			color: var(--text-muted); 
			font-weight: 500; /* 稍微加重一点，显得更有质感 */
		}

		.input-section { margin-bottom: 15px; }

		.label-row { 
			font-size: 0.85rem; 
			color: var(--text-muted); 
			font-weight: 600; 
			margin-bottom: 8px; 
		}

		.ping-value { 
			font-family: inherit;
			font-weight: 600; 
			font-size: 0.85rem;
		}

		.action-area { display: flex; align-items: center; gap: 12px; }

		.url-box { 
			flex: 1; 
			background-color: var(--code-bg); 
			padding: 0 16px; 
			height: 42px; 
			border-radius: 8px; 
			border: 1px solid rgba(255,255,255,0.05); 
			display: flex; 
			align-items: center; 
			overflow: hidden; 
		}

		.url-box.no-btn { opacity: 0.8; }

		.url-text { 
			font-family: ui-monospace, SFMono-Regular, Monaco, Consolas, monospace; 
			font-size: 0.85rem; 
			color: var(--text-muted); 
			white-space: nowrap; 
			overflow: hidden; 
			text-overflow: ellipsis; 
			width: 100%; 
		}

		.copy-btn { 
			background: rgba(59, 130, 246, 0.15); 
			color: var(--accent-blue); 
			border: 1px solid rgba(59, 130, 246, 0.4); 
			height: 42px; 
			padding: 0 20px; 
			border-radius: 8px; 
			cursor: pointer; 
			font-size: 0.85rem; 
			font-weight: 700; 
			transition: 0.3s; 
			white-space: nowrap; 
		}

		.copy-btn:hover { background: var(--accent-blue); color: #fff; }

		.copy-btn.success { background: #10b981; border-color: #10b981; color: #fff; }

		footer { text-align: center; margin-top: 50px; padding-top: 30px; border-top: 1px solid var(--border-color); }

		@media (max-width: 600px) { 
			.action-area { flex-direction: column; align-items: stretch; }
			.url-box { margin-bottom: 8px; }
		}
	</style>
</head>
<body>
<div class="container">
    <header>
        <h1>自建 DoH 服务</h1>
        <div class="sub-title">安全加密 · 支持 ECH</div>
    </header>
    <section>${cardsHtml}</section>
    <footer>
        <a href="https://www.youtube.com/@zhenxiangdinglv" target="_blank" style="display:inline-block; background:linear-gradient(135deg, #3b82f6, #2563eb); color:#fff; padding:10px 25px; border-radius:50px; text-decoration:none; font-weight:700;">YouTube 真香定律</a>
    </footer>
</div>
<div id="toast" style="position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#1e293b;color:#fff;padding:8px 20px;border-radius:30px;font-size:0.8rem;z-index:1000;display:none;"></div>
<script>
const services = ${JSON.stringify(services)};
const dnsQueryPayload = 'q80BAAABAAAAAAAAA3d3dwdnb29nbGUDY29tAAABAAE';
const runningPings = new Set();

function showMsg(txt){
    var t=document.getElementById('toast');
    t.textContent=txt; t.style.display='block';
    setTimeout(function(){t.style.display='none';},2000);
}

function copyUrl(str,btn){
    navigator.clipboard.writeText(str).then(function(){
        showMsg('已复制');
        var old=btn.textContent; btn.textContent='已复制'; btn.classList.add('success');
        setTimeout(function(){btn.textContent=old; btn.classList.remove('success');},1800);
    });
}

async function performFetch(url) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 800);
    try {
        const start = Date.now();
        await fetch(url + '?dns=' + dnsQueryPayload, { 
            method: 'GET', 
            mode: 'no-cors', 
            cache: 'no-store',
            signal: controller.signal 
        });
        clearTimeout(timeoutId);
        return Date.now() - start;
    } catch (e) {
        clearTimeout(timeoutId);
        throw e;
    }
}

async function checkPing(url, elId) {
    if (runningPings.has(elId)) return;
    runningPings.add(elId);
    const el = document.getElementById(elId);
    try {
        const latency = await performFetch(url);
        el.textContent = '延迟：' + latency + 'ms';
    } catch (e) {
        try {
            const latency2 = await performFetch(url);
            el.textContent = '延迟：' + latency2 + 'ms';
        } catch (e2) {
            el.textContent = '被墙了，请用反代 DoH';
        }
    } finally {
        runningPings.delete(elId);
    }
}

function testAll(){
    services.forEach(s => {
        const id = s.path.replace('/', '');
        checkPing(window.location.origin + s.path + '/dns-query', 'proxy-ping-' + id);
        checkPing(s.upstream, 'up-ping-' + id);
    });
}

document.querySelectorAll('.copy-btn').forEach(function(btn){
    btn.addEventListener('click', function(){ copyUrl(this.getAttribute('data-url'), this); });
});

testAll();
</script>
</body>
</html>`;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (url.pathname === '/' || url.pathname === '') {
      return new Response(buildPage(request), {
        headers: { 'Content-Type': 'text/html; charset=utf-8' }
      });
    }
    for (const [path, upstream] of Object.entries(routes)) {
      if (url.pathname.startsWith(path)) {
        const remainingPath = url.pathname.slice(path.length).replace(/^\/+/, '');
        const targetUrl = new URL(remainingPath, upstream + (upstream.endsWith('/') ? '' : '/'));
        targetUrl.search = url.search;
        const newRequest = new Request(targetUrl, {
          method: request.method,
          headers: new Headers(request.headers),
          body: request.body,
          redirect: 'follow'
        });
        newRequest.headers.set('Host', new URL(upstream).hostname);
        newRequest.headers.set('Accept', 'application/dns-message');
        const response = await fetch(newRequest, { cf: { cacheEverything: true, cacheTtl: 10 } });
        const newHeaders = new Headers(response.headers);
        newHeaders.set('Access-Control-Allow-Origin', '*');
        return new Response(response.body, { status: response.status, headers: newHeaders });
      }
    }
    return new Response('Not Found', { status: 404 });
  }    
};